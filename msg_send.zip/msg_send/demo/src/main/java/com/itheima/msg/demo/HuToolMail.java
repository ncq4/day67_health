package com.itheima.msg.demo;

import cn.hutool.extra.mail.MailAccount;
import cn.hutool.extra.mail.MailUtil;

public class HuToolMail {

    public static void main(String[] args) {
        MailAccount mailAccount = new MailAccount();
        mailAccount.setHost("smtp.163.com");
        mailAccount.setPort(25);
        mailAccount.setAuth(true);

        mailAccount.setFrom("tensquare_itcast@163.com");
        mailAccount.setUser("tensquare_itcast@163.com");
        mailAccount.setPass("IDGPFWRTPMRFWLXB");

        MailUtil.send(mailAccount, "tensquare_itcast@163.com", "测试邮件", "邮件来自于HuTool工具的发送", false);
    }
}
