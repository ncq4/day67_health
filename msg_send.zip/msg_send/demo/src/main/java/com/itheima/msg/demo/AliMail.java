package com.itheima.msg.demo;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dm.model.v20151123.BatchSendMailRequest;
import com.aliyuncs.dm.model.v20151123.SingleSendMailRequest;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;

public class AliMail {

    public static void main(String[] args) {
        //sendMail();
        sendBatch();
    }

    private static void sendBatch() {
        IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou",
                "LTAI4FpSmghKjkTkPeS55cwc", "Y60WohY13Bdh8uBoRukecQus1BhN0f");
        IAcsClient client = new DefaultAcsClient(profile);

        try {
            BatchSendMailRequest request = new BatchSendMailRequest();

            //设置发件人的邮件地址
            request.setAccountName("msg@mail.xuziyi.top");
            //设置模板名称
            request.setTemplateName("节日礼包");
            //设置收件人列表名称
            request.setReceiversName("节日礼包Mail列表");

            request.setAddressType(1);
            request.setMethod(MethodType.POST);

            client.getAcsResponse(request);
        } catch (Exception e) {

        }
    }

    /**
     * 触发邮件
     */
    private static void sendMail() {
        //创建客户端，操作阿里邮件推送平台
        //第一个参数是固定写法，发送国内的邮件使用 cn-hangzhou
        //第二个参数是AccessKey
        //第三个参数是Access Key Secret
        IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou",
                "LTAI4FpSmghKjkTkPeS55cwc", "Y60WohY13Bdh8uBoRukecQus1BhN0f");
        IAcsClient client = new DefaultAcsClient(profile);

        SingleSendMailRequest request = new SingleSendMailRequest();

        try {
            //在请求中设置发送者信息
            request.setAccountName("admin@mail.xuziyi.top");
            request.setFromAlias("管理员");
            request.setAddressType(1);
            request.setReplyToAddress(true);

            //设置目标用户的信息
            request.setToAddress("tensquare_itcast@163.com");
            request.setSubject("阿里邮件推送测试");
            request.setHtmlBody("<h3>阿里邮件推送测试正文</h3>");

            request.setMethod(MethodType.POST);

            client.getAcsResponse(request);
        } catch (ClientException e) {
            e.printStackTrace();
        }
    }
}
