package com.itheima.msg.demo;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class ThreadSyncDemo {

    //创建线程池
    private static ExecutorService pool = Executors.newFixedThreadPool(4);

    public static void main(String[] args) {
        //test1();
        test2();

        pool.shutdown();
    }

    private static void test2() {
        System.out.println("test2-1");
        CountDownLatch countDownLatch = new CountDownLatch(2);

        //要执行的任务1（发送一种消息）
        AtomicInteger b1 = new AtomicInteger(2);
        pool.execute(() -> {
            try {
                b1.addAndGet(2);
                TimeUnit.MILLISECONDS.sleep(20);
                System.out.println("test2-21");
                countDownLatch.countDown();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        //要执行的任务2（发送另一种消息）
        AtomicInteger b2 = new AtomicInteger(20);
        pool.execute(() -> {
            try {
                b2.addAndGet(20);
                TimeUnit.MILLISECONDS.sleep(10);
                System.out.println("test2-22");
                countDownLatch.countDown();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        //不知道任务要执行多久，所以延时的方式不可取
        //try {
        //    TimeUnit.MILLISECONDS.sleep(10);
        //} catch (InterruptedException e) {
        //    e.printStackTrace();
        //}
        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println(b1.get() + ":::" + b2.get());
    }

    private static void test1() {
        System.out.println("test1-1");
        //要执行的任务1（发送一种消息）
        Future<Integer> f1 = pool.submit(() -> {
            int a = 1 + 1;
            TimeUnit.MILLISECONDS.sleep(20);
            System.out.println("test1-21");
            return a;
        });

        //要执行的任务2（发送另一种消息）
        Future<Integer> f2 = pool.submit(() -> {
            int a = 10 + 10;
            TimeUnit.MILLISECONDS.sleep(10);
            System.out.println("test1-22");
            return a;
        });


        try {
            //获取返回结果
            Integer r1 = f1.get();
            Integer r2 = f2.get();
            System.out.println("test1-3");
            System.out.println(r1 + ":::" + r2);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }
}
