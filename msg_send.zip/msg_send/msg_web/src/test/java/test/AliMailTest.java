package test;

import com.itheima.msg.web.MsgApplication;
import com.itheima.msg.web.dto.AliMailMsgDto;
import com.itheima.msg.web.sender.AliMailMsgSender;
import com.itheima.msg.web.thread.MsgThread;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.concurrent.TimeUnit;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MsgApplication.class)
public class AliMailTest {

    @Autowired
    private AliMailMsgSender sender;

    //触发邮件
    @Test
    public void test() {
        AliMailMsgDto dto = AliMailMsgDto.builder()
                .triggerName("admin@mail.xuziyi.top")
                .triggerAlias("管理员")
                .address("tensquare_itcast@163.com")
                .subject("消息发送中心测试")
                .content("<h3>消息发送中心测试内容</h3>")
                .build();
        sender.send(dto);
    }

    //批量邮件
    @Test
    public void test2() {

        AliMailMsgDto dto = AliMailMsgDto.builder()
                .bathchName("msg@mail.xuziyi.top")
                .template("节日礼包")
                .receivers("节日礼包Mail列表")
                .build();

        sender.batchSend(dto);
    }

    @Qualifier("aliMailMsgThread")
    @Autowired
    private MsgThread msgThread;

    //多线程邮件发送，同步，需要返回发送的结果
    @Test
    public void test3() {
        AliMailMsgDto dto1 = AliMailMsgDto.builder()
                .triggerName("admin@mail.xuziyi.top")
                .triggerAlias("管理员")
                .address("tensquare_itcast@163.com")
                .subject("消息发送中心测试")
                .content("<h3>消息发送中心测试内容</h3>")
                .build();

        msgThread.send(dto1);


        AliMailMsgDto dto2 = AliMailMsgDto.builder()
                .bathchName("msg@mail.xuziyi.top")
                .template("节日礼包")
                .receivers("节日礼包Mail列表")
                .build();
        msgThread.sendBatch(dto2);
    }

    //多线程邮件发送，异步，不需要发送的返回结果
    @Test
    public void test4() {
        AliMailMsgDto dto1 = AliMailMsgDto.builder()
                .triggerName("admin@mail.xuziyi.top")
                .triggerAlias("管理员")
                .address("tensquare_itcast@163.com")
                .subject("消息发送中心测试")
                .content("<h3>消息发送中心测试内容</h3>")
                .build();

        msgThread.asyncSend(dto1);


        AliMailMsgDto dto2 = AliMailMsgDto.builder()
                .bathchName("msg@mail.xuziyi.top")
                .template("节日礼包")
                .receivers("节日礼包Mail列表")
                .build();
        msgThread.asyncSendBatch(dto2);

        try {
            TimeUnit.MILLISECONDS.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
