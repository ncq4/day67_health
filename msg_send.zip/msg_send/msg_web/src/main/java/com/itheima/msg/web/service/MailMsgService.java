package com.itheima.msg.web.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.itheima.msg.common.utils.Result;
import com.itheima.msg.web.dto.AliMailMsgDto;
import com.itheima.msg.web.entity.MailMsg;

public interface MailMsgService extends IService<MailMsg> {

    void saveResult(AliMailMsgDto aliMailMsgDto, Result result);
}
