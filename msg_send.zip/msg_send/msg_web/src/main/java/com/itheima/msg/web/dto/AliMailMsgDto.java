package com.itheima.msg.web.dto;

import lombok.*;

@Data
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
public class AliMailMsgDto {

    //应用名称
    private String appName;

    //------单个邮件-----
    //触发邮件的发件地址
    private String triggerName;
    //触发邮件的发件昵称
    private String triggerAlias;
    //目标邮箱地址
    private String address;
    //邮件主题
    private String subject;
    //邮件正文
    private String content;

    //------批量邮件------
    //批量邮件的发件地址
    private String bathchName;
    //收件人列表名称
    private String receivers;
    //模板名称
    private String template;

}
