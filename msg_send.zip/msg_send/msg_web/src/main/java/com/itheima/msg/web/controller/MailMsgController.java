package com.itheima.msg.web.controller;

import com.itheima.msg.common.utils.Result;
import com.itheima.msg.web.service.MailMsgService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

//请求路径第一个参数使用 sync--同步处理    async--异步处理
//请求路径第二个参数appName，传递不同应用的应用名，以方便管理
@Slf4j
@RestController
@RequestMapping("mail")
@Api(tags = "发送邮箱信息")
@Validated
public class MailMsgController {

    @Autowired
    private MailMsgService mailMsgService;

    //POST   /mail/code/{sync}/{appName}		发送邮箱验证码
    @ApiImplicitParams({
            @ApiImplicitParam(name = "sync", value = "sync同步，async异步", required = true),
            @ApiImplicitParam(name = "appName", value = "应用名称", required = true),
            @ApiImplicitParam(name = "mail", value = "目标邮箱地址", required = true),
            @ApiImplicitParam(name = "code", value = "验证码", required = true),
    })
    @ApiOperation(value = "发送邮箱验证码")
    @PostMapping(value = "code/{sync}/{appName}")
    public Result sendCode(@PathVariable String sync, @PathVariable String appName,
                           @Email @NotBlank(message = "邮箱不能为空") String mail,
                           @NotBlank(message = "验证码不能为空") String code) {
        log.debug("发送邮箱验证码：appName={},sync={},mail={},code={}", appName, sync, mail, code);
        return mailMsgService.sendCode(appName, sync, mail, code);
    }

    //POST   /mail/notify/{sync}/{appName}	   发送邮箱通知
    @ApiImplicitParams({
            @ApiImplicitParam(name = "sync", value = "sync同步，async异步", required = true),
            @ApiImplicitParam(name = "appName", value = "应用名称", required = true),
            @ApiImplicitParam(name = "mail", value = "目标邮箱地址", required = true),
            @ApiImplicitParam(name = "subject", value = "邮件通知主题", required = true),
            @ApiImplicitParam(name = "content", value = "邮件通知主题", required = true),
    })
    @ApiOperation(value = "发送邮箱通知")
    @PostMapping(value = "notify/{sync}/{appName}")
    public Result sendNotify(@PathVariable String sync, @PathVariable String appName,
                             @Email @NotBlank(message = "邮箱不能为空") String mail,
                             @NotBlank(message = "通知主题不能为空") String subject,
                             @NotBlank(message = "通知内容不能为空") String content) {
        log.debug("发送邮箱验证码：appName={},sync={},mail={},subject={},content={}",
                appName, sync, mail, subject, content);
        return mailMsgService.sendNotify(appName, sync, mail, subject, content);
    }

    //POST   /mail/holiday/{sync}/{appName}	发送节日礼包提醒
    @ApiImplicitParams({
            @ApiImplicitParam(name = "sync", value = "sync同步，async异步", required = true),
            @ApiImplicitParam(name = "appName", value = "应用名称", required = true)
    })
    @ApiOperation(value = "批量发送节日礼包提醒")
    @PostMapping(value = "holiday/{sync}/{appName}")
    public Result sendHoliday(@PathVariable String sync, @PathVariable String appName) {
        log.debug("发送节日礼包提醒：appName={}，sync={}", appName, sync);
        return mailMsgService.sendHoliday(appName, sync);
    }

}
