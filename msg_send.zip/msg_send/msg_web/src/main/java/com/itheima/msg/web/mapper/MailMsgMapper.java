package com.itheima.msg.web.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.itheima.msg.web.entity.MailMsg;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MailMsgMapper extends BaseMapper<MailMsg> {
}