package com.itheima.msg.web.thread;

import com.itheima.msg.common.utils.Result;

public interface MsgThread<T> {

    /**
     * 发送消息，一次发送一条消息
     *
     * @param msgData 消息数据
     */
    Result send(T msgData);


    /**
     * 发送批量消息
     *
     * @param msgData
     */
    Result sendBatch(T msgData);
}
