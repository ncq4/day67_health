package com.itheima.msg.web.sender;

import com.itheima.msg.common.utils.Result;

/**
 * <pre>
 * 消息发送器接口
 * </pre>
 */
public interface MsgSender<T> {

    /**
     * 发送消息
     *
     * @param msgData 消息数据
     */
    Result send(T msgData);

    /**
     * 批量发送消息
     *
     * @param msgData
     */
    Result batchSend(T msgData);

}
