package com.itheima.msg.web.thread;

import com.itheima.msg.common.utils.Result;
import com.itheima.msg.web.dto.AliMailMsgDto;
import com.itheima.msg.web.sender.MsgSender;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

/**
 * 阿里邮件消息发送服务线程类
 */
@Slf4j
@Component
public class AliMailMsgThread extends BaseMsgThread implements MsgThread<AliMailMsgDto> {

    //注入发送邮件的实例
    @Qualifier("aliMailMsgSender")
    @Autowired
    private MsgSender msgSender;

    @Override
    public Result send(AliMailMsgDto msgData) {
        Future<Result> future = getPool().submit(() -> msgSender.send(msgData));

        try {
            return future.get();
        } catch (Exception e) {
            log.error(ExceptionUtils.getStackTrace(e));
        }

        return Result.error("发送邮件消息错误");
    }

    @Override
    public Result sendBatch(AliMailMsgDto msgData) {
        Future<Result> future = getPool().submit(() -> msgSender.batchSend(msgData));

        try {
            return future.get();
        } catch (Exception e) {
            log.error(ExceptionUtils.getStackTrace(e));
        }

        return Result.error("发送邮件消息错误");
    }
}
