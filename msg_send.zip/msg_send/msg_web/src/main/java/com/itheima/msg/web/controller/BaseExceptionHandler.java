package com.itheima.msg.web.controller;

import com.itheima.msg.common.exception.MsgException;
import com.itheima.msg.common.utils.Result;
import com.itheima.msg.common.utils.ResultCode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;
import java.util.Set;

@Slf4j
@ControllerAdvice
public class BaseExceptionHandler {

    @ExceptionHandler(Exception.class)
    @ResponseBody
    public Result handler(Exception e) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        log.error(sw.toString());
        return Result.error(ResultCode.ERROR, "服务错误，请稍候再试");
    }

    @ExceptionHandler(MsgException.class)
    @ResponseBody
    public Result handler(MsgException e) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        log.error(sw.toString());
        return Result.error(ResultCode.BAD_REQUEST, e.getMessage());
    }

    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseBody
    public Result handler(ConstraintViolationException e) {
        StringBuffer errorMsg = new StringBuffer();
        Set<ConstraintViolation<?>> violations = e.getConstraintViolations();
        violations.stream().forEach(x -> errorMsg.append(x.getMessage()).append(";"));
        log.error("[ConstraintViolationException]" + errorMsg.toString());
        return Result.error(ResultCode.BAD_REQUEST, errorMsg.toString());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseBody
    public Result handler(MethodArgumentNotValidException e) {
        StringBuffer errorMsg = new StringBuffer();
        List<ObjectError> errors = e.getBindingResult().getAllErrors();
        errors.stream().forEach(x -> errorMsg.append(x.getDefaultMessage()).append(";"));
        log.error("[MethodArgumentNotValidException]" + errorMsg.toString());
        return Result.error(ResultCode.BAD_REQUEST, errorMsg.toString());
    }

    @ExceptionHandler(BindException.class)
    @ResponseBody
    public Result handler(BindException e) {
        StringBuffer errorMsg = new StringBuffer();
        List<ObjectError> errors = e.getAllErrors();
        errors.stream().forEach(x -> errorMsg.append(x.getDefaultMessage()).append(";"));
        log.error("[BindException]" + errorMsg.toString());
        return Result.error(ResultCode.BAD_REQUEST, errorMsg.toString());
    }

}