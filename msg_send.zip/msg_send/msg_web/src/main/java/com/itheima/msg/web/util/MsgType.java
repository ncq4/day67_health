package com.itheima.msg.web.util;

/**
 * <pre>
 * 消息类型常量
 * </pre>
 */
public enum MsgType {
    /**
     * 消息类型
     */
    MP_TEMPLATE(1, "公众号-模板消息"),
    MA_TEMPLATE(2, "小程序-模板消息"),
    KEFU(3, "公众号-客服消息"),
    KEFU_PRIORITY(4, "公众号-客服消息优先"),
    ALI_YUN(5, "阿里云短信"),
    TX_YUN(7, "腾讯云短信"),
    YUN_PIAN(8, "云片网短信"),
    UP_YUN(9, "又拍云短信"),
    HW_YUN(10, "华为云短信"),
    EMAIL(11, "E-Mail"),
    WX_CP(12, "微信企业号/企业微信"),
    HTTP(13, "HTTP请求"),
    DING(14, "钉钉"),
    BD_YUN(15, "百度云短信"),
    QI_NIU_YUN(16, "七牛云短信"),
    WX_UNIFORM_MESSAGE(17, "小程序-统一服务消息"),
    MA_SUBSCRIBE(18, "小程序-订阅消息");

    private int code;
    private String name;

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    MsgType(int code, String name) {
        this.code = code;
        this.name = name;
    }
}
