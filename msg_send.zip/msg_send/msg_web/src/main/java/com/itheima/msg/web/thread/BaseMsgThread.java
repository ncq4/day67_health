package com.itheima.msg.web.thread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 消息发送服务线程父类，维护线程池
 */
public abstract class BaseMsgThread {

    private static ExecutorService pool;

    static {
        int cpuCount = Runtime.getRuntime().availableProcessors();

        //使用java虚拟机能够调用的处理器核心数*2
        pool = Executors.newFixedThreadPool(cpuCount * 2);
    }


    public ExecutorService getPool() {
        return pool;
    }
}
