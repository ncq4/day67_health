package com.itheima.msg.web.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.itheima.msg.common.utils.Result;
import com.itheima.msg.common.utils.ResultCode;
import com.itheima.msg.web.dto.AliMailMsgDto;
import com.itheima.msg.web.mapper.MailMsgMapper;
import com.itheima.msg.web.service.MailMsgService;
import com.itheima.msg.web.util.MsgType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;

@Slf4j
@Service
public class MailMsgServiceImpl extends ServiceImpl<MailMsgMapper, MailMsg> implements MailMsgService {

    @Override
    public void saveResult(AliMailMsgDto msgDto, Result result) {
        MailMsg mailMsg = new MailMsg();
        mailMsg.setAppName(msgDto.getAppName());
        mailMsg.setMsgType(MsgType.EMAIL.getCode());

        mailMsg.setMsgName(msgDto.getAddress());
        mailMsg.setSubject(msgDto.getSubject());
        mailMsg.setContent(msgDto.getContent());

        mailMsg.setSuccess(result.getStatus() == ResultCode.OK);
        mailMsg.setResultMsg(result.getData() != null ? result.getData().toString() : "");

        save(mailMsg);
    }
}
