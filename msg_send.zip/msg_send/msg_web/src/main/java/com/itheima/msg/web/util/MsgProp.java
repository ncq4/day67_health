package com.itheima.msg.web.util;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Map;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "aliyun")
public class MsgProp {

    //          应用名称  配置的属性  配置的值
    private Map<String,Map<String ,String>> mail;
}
