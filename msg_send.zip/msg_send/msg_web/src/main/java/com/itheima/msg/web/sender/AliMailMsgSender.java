package com.itheima.msg.web.sender;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dm.model.v20151123.BatchSendMailRequest;
import com.aliyuncs.dm.model.v20151123.BatchSendMailResponse;
import com.aliyuncs.dm.model.v20151123.SingleSendMailRequest;
import com.aliyuncs.http.HttpClientConfig;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.itheima.msg.common.utils.Result;
import com.itheima.msg.common.utils.ResultCode;
import com.itheima.msg.web.dto.AliMailMsgDto;
import com.itheima.msg.web.service.MailMsgService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * <pre>
 * E-Mail发送器
 * </pre>
 */
@Slf4j
@Component
public class AliMailMsgSender implements MsgSender<AliMailMsgDto> {

    @Value("${aliyun.accessKey}")
    private String accessKey;
    @Value("${aliyun.accessKeySecret}")
    private String accessKeySecret;
    @Value("${aliyun.maxRequestsPerHost}")
    private int maxRequestsPerHost;


    @Autowired
    private MailMsgService mailMsgService;

    /**
     * 阿里云短信client
     */
    private volatile static IAcsClient iAcsClient;

    @Override
    public Result send(AliMailMsgDto msgData) {
        Result result = null;
        try {
            SingleSendMailRequest request = new SingleSendMailRequest();
            request.setAccountName(msgData.getTriggerName());
            request.setFromAlias(msgData.getTriggerAlias());
            request.setAddressType(1);
            request.setReplyToAddress(true);
            request.setToAddress(msgData.getAddress());
            request.setSubject(msgData.getSubject());
            request.setHtmlBody(msgData.getContent());
            //SDK 采用的是http协议的发信方式, 默认是GET方法，有一定的长度限制。
            //若textBody、htmlBody或content的大小不确定，建议采用POST方式提交，避免出现uri is not valid异常
            request.setMethod(MethodType.POST);
            //如果调用成功，正常返回httpResponse；如果调用失败则抛出异常，需要在异常中捕获错误异常码；错误异常码请参考对应的API文档;
            getClient().getAcsResponse(request);

            result = result.builder()
                    .status(ResultCode.OK)
                    .msg("邮件发送成功")
                    .build();

        } catch (Exception e) {
            log.error(ExceptionUtils.getStackTrace(e));
            result = result.builder()
                    .status(ResultCode.ERROR)
                    .msg("邮件发送异常")
                    .data(ExceptionUtils.getMessage(e))
                    .build();
        }

        try {
            //保存数据
            mailMsgService.saveResult(msgData, result);
        } catch (Exception e) {
            log.error(ExceptionUtils.getStackTrace(e));
        }

        return result;
    }

    @Override
    public Result batchSend(AliMailMsgDto msgData) {
        Result result = null;

        try {
            BatchSendMailRequest request = new BatchSendMailRequest();

            request.setAccountName(msgData.getBathchName());
            request.setTemplateName(msgData.getTemplate());
            request.setReceiversName(msgData.getReceivers());

            request.setAddressType(1);
            request.setMethod(MethodType.POST);

            BatchSendMailResponse acsResponse = getClient().getAcsResponse(request);

            //封装返回对象
            result = result.builder()
                    .status(ResultCode.OK)
                    .msg("邮件批量发送成功")
                    .build();

        } catch (Exception e) {
            log.error(ExceptionUtils.getStackTrace(e));
            result = result.builder()
                    .status(ResultCode.ERROR)
                    .msg("邮件批量发送失败")
                    .data(e.getMessage())
                    .build();
        }

        //保存消息发送数据到MySQL中
        try {
            mailMsgService.saveResult(msgData,result);
        } catch (Exception e) {
            log.error(ExceptionUtils.getStackTrace(e));
        }

        return result;
    }

    /**
     * 获取阿里云邮件发送客户端
     */
    private IAcsClient getClient() {
        if (iAcsClient == null) {
            synchronized (AliMailMsgSender.class) {
                if (iAcsClient == null) {
                    // 创建DefaultAcsClient实例并初始化
                    DefaultProfile profile = DefaultProfile.getProfile("cn-hangzhou", accessKey, accessKeySecret);

                    // 每个host的最大连接数，超时时间等
                    HttpClientConfig clientConfig = HttpClientConfig.getDefault();
                    clientConfig.setMaxRequestsPerHost(maxRequestsPerHost);
                    clientConfig.setConnectionTimeoutMillis(10000L);

                    profile.setHttpClientConfig(clientConfig);
                    iAcsClient = new DefaultAcsClient(profile);
                }
            }
        }
        return iAcsClient;
    }
}
