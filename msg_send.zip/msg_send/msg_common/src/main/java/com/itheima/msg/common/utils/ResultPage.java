package com.itheima.msg.common.utils;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.List;

/**
 * 分页结果包装
 */
@Data
@Accessors(chain = true)
@ApiModel(value = "分页数据消息体", description = "分页数据统一对象")
@Builder
public class ResultPage<T> implements Serializable {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "返回状态", required = true)
    private int status;

    @ApiModelProperty(value = "状态信息", required = true)
    private String msg;

    @ApiModelProperty(value = "总条目数", required = true)
    private Long total;

    @ApiModelProperty(value = "页尺寸", required = true)
    private Integer pageSize;

    @ApiModelProperty(value = "总页数", required = true)
    private Long pages;

    @ApiModelProperty(value = "页码", required = true)
    private Integer pageNum;

    @ApiModelProperty(value = "数据列表", required = true)
    private List<T> items;

    public static ResultPage ok(Long total, Integer pageSize, Long pages, Integer pageNum, List items) {
        return ResultPage.builder()
                .status(ResultCode.OK)
                .msg("操作成功")
                .total(total)
                .pageSize(pageSize)
                .pageNum(pageNum)
                .pages(pages)
                .items(items)
                .build();
    }

    public static ResultPage ok(int code, String msg, Long total, Integer pageSize, Long pages, Integer pageNum, List items) {
        return ResultPage.builder()
                .status(code)
                .msg(msg)
                .total(total)
                .pageSize(pageSize)
                .pageNum(pageNum)
                .pages(pages)
                .items(items)
                .build();
    }
}
