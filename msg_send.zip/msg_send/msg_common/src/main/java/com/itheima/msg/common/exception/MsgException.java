package com.itheima.msg.common.exception;

import com.itheima.msg.common.utils.ResultCode;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 消息异常
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class MsgException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    private String msg;
    private int code = ResultCode.ERROR;

    public MsgException(String msg) {
        super(msg);
        this.msg = msg;
    }

    public MsgException(String msg, Throwable e) {
        super(msg, e);
        this.msg = msg;
    }

    public MsgException(String msg, int code) {
        super(msg);
        this.msg = msg;
        this.code = code;
    }

    public MsgException(String msg, int code, Throwable e) {
        super(msg, e);
        this.msg = msg;
        this.code = code;
    }

}
